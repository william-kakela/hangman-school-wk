/*
1. Du ska bygga det klassiska spelet hänga gubbe.
2. Det ska vara gjort med HTML/CSS/Javascript
3. Användaren ska kunna mata in med tangentbordet bokstäver
4. Användaren ska kunna se vilka bokstäver den gissar rätt på och var i ordet de
hamnar
5. Vid varje fel ska en del av gubben visas
6. Ifall användaren gissar på rätt ord så ska en ”Du vann”-skärm visas med en
fråga om man vill spela igen,
7. Ifall användaren inte hinner gissa rätt ska en ”Du förlorade”-skärm visas med
det rätta ordet och en fråga om man vill spela igen.
8. Du ska enbart kunna gissa på en bokstav i taget.

 */
let wordBank = ['hello', 'house', 'fun', 'mouse', 'car', 'food', 'hockey', 'speed', 'cool'];
let word = wordBank[Math.floor(Math.random() * wordBank.length)];
let splitWord = word.split('');
console.log(splitWord);
let filledArray = new Array(splitWord.length).fill('_');
console.log('gissa ordet');
let numOfGuesses = 0;
let seconds = 60;
let timer;
function myFunction() {
    if (seconds < 60) {
        document.getElementById("timer").innerHTML = seconds;
    }
    if (seconds > 0) {
        seconds--;
    } else {
        clearInterval(timer);
        if (confirm('you lost try again?')) {
            window.location.reload()
        }
    }
}
document.getElementById("timer").innerHTML = "1:00";


document.querySelector('#startButton').addEventListener('click', function () {
    document.querySelector('#box').innerHTML = '';
    let show = document.createElement('p');

    show.innerHTML = filledArray;

    document.querySelector('#box').append(show);
    document.querySelector('#startButton').getElementsByClassName.display = 'none';


    if (!timer) {
        timer = window.setInterval(function () {
            myFunction();
        }, 1000);
    }

});

window.addEventListener('keyup', function (event) {
    let pressedLetter = event.key;
    if (splitWord.indexOf(pressedLetter) !== -1) {
        for (let i = 0; i < splitWord.length; i++) {

            if (splitWord[i] == pressedLetter) {

                console.log('du hittade', splitWord[i]);

                filledArray[i] = splitWord[i];

                if (!filledArray.includes('_')) {
                    setTimeout(function () {
                        alert('du vann!');
                        window.location.reload()
                    }, 1000)
                }

            }
        }
    } else {
        console.log('bokstaven finns inte i ordet')
        numOfGuesses = numOfGuesses + 1;
        addParts();
    }
    document.querySelector('#box').innerHTML = '';
    let text = document.createElement('p');
    text.innerHTML = filledArray;
    document.querySelector('#box').append(text);

});

function addParts() {
    if (numOfGuesses == 1) {
        document.querySelector('figure').classList.add('scaffold');
    } else if (numOfGuesses == 2) {
        document.querySelector('figure').classList.add('head');
    } else if (numOfGuesses == 3) {
        document.querySelector('figure').classList.add('body');
    } else if (numOfGuesses == 4) {
        document.querySelector('figure').classList.add('arms');
    } else if (numOfGuesses == 5) {
        document.querySelector('figure').classList.add('legs');
        if (confirm('you lost try again?')) {
            window.location.reload()
        }
    }
};


